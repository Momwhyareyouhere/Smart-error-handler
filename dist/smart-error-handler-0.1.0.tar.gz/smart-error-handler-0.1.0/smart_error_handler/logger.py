class Logger:
    def log(self, message):
        print(f"LOG: {message}")