from setuptools import setup, find_packages

setup(
    name="smart-error-handler",
    version="0.1.0",
    packages=find_packages(),
    description="A smart error handler",
    author="Momwhyareyouhere"
)